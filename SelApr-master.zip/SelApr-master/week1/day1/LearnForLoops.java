package week1.day1;

public class LearnForLoops {

	public static void main(String[] args) {
		int i;
		for(i =1; i<=10;i++) {
			System.out.println(i);
		}
		System.out.println(i);
		System.out.println(i);
		
		
		
		
		/*int num = 10;
//		num++; // num = num + 1;
//		++num;
		
		System.out.println(num++);
		System.out.println(num);*/
	}

}



