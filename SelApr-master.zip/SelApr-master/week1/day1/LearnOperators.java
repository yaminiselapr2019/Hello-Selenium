package week1.day1;

public class LearnOperators {
	// global or instance variable

	public static void main(String[] args) {
		// local variable
		
		int age = 20;
		if (age >= 60) {
			System.out.println("senior");
		}else if (age >= 18) {
			System.out.println("adult");
		}else {
			System.out.println("not an adult");
		}
		/*if(age >= 18 ) 
			System.out.println("eligible for vote");
		else 
			System.out.println("not eligible");		*/	
		
		
		
		
		
		/*int num1 = 17;
		int num2 = 17;
		boolean modulo = !(num1 > 10 || num2 > 20);
		System.out.println(modulo);*/
		
		
	}

}




