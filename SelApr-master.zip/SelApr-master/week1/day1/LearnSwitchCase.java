package week1.day1;

public class LearnSwitchCase {
	public static void main(String[] args) {
		int choice = 2;
		switch(choice) {
		case 1:
			System.out.println("Kannada");
			break;
		case 2:
			System.out.println("Tamil");
			break;
		default:
			System.out.println("English");
			break;
		}


	}

}
