package week1.day1;

public class MyMobile {
	public static void main(String[] args) {
		// syntax to invoke a class
		// ClassName object = new ClassName();
		// syntax to call a method
		// object.methodName();
		Mobile myMobile = new Mobile();
		String color = myMobile.getColor("moto");
		System.out.println(color);
		System.out.println(myMobile.hasFaceReg);
		
	}

}





