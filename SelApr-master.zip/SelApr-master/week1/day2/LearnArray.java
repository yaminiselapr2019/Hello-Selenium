package week1.day2;

public class LearnArray {

	public static void main(String[] args) {
		String mobileModel[] = {"Nokia","Blackberry",
				"Apple","Samsung","OnePlus"};
		for(int i=0; i<mobileModel.length ; i++)
		System.out.println(mobileModel[i]);

	}

}
