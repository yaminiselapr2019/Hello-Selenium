package week1.day2;

public class LearnPrim {

	public static void main(String[] args) {
		long age = 13000000000L;
		float temp = 33.6f;	
		char text = 'A';
		System.out.println(age);
	}

}
