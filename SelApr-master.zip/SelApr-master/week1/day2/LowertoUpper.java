package week1.day2;

public class LowertoUpper {
	public static void main(String[] args) {
		/*char ch = 'a';
		int num = ch;
		ch =  (char) (num-32);
		System.out.println(ch);*/
		
		char ch = 'a';
		String str = ch+"";
		System.out.println(str.toUpperCase());
	}
}
