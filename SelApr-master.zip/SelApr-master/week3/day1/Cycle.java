package week3.day1;

public class Cycle {
public void doPedal() {
	System.out.println("This is pedal from Cycle!");
}
}
