package week3.day1;

public interface Mobile2020 {
	
	public String model = "One plus 7T";
	
	public void quickCharge();
	
	public void enableHologram();
	
	public void foldableLCD();
	
	public void enableSolarCharging();

}
