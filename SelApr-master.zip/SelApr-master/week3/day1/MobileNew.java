package week3.day1;

public class MobileNew {
	
	
	public static void enableHologram() {
		System.out.println("Hologram available");

	}

}
