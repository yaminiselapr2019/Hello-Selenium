package week3.day1;

public class MobileSub extends Mobileforfuture{

	public final int version=10;
	
	

	public  void enableHologram() {
		System.out.println("Hologram Not available");

	}

	public void foldableLCD() {
		// TODO Auto-generated method stub

	}

	public void enableSolarCharging() {
		// TODO Auto-generated method stub

	}

	@Override
	public void longStandingBattery() {
		// TODO Auto-generated method stub

	}

}
