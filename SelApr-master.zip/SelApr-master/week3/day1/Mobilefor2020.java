package week3.day1;

public class Mobilefor2020 implements Mobile2020{

	public void quickCharge() {
		System.out.println("Specific Li Batteries");
	}

	public void enableHologram() {
		// TODO Auto-generated method stub

	}

	public void foldableLCD() {
		// TODO Auto-generated method stub

	}

	public void enableSolarCharging() {
		// TODO Auto-generated method stub
		
	}
	
	public void dualDisplay() {
		System.out.println("Dual display");
	}
	
	
	
	
	
	
	

}
