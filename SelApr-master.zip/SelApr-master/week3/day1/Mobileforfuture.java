package week3.day1;

public abstract class Mobileforfuture implements Mobile2020{
	public void quickCharge() {
		System.out.println("Implement Li Battery");
	}
	
	public abstract void longStandingBattery();
	
	public void dualSidedDisplay() {
		System.out.println("Dual side display");
	}
	
	
}
