package week3.day1;

public class MyMobile {

	public static void main(String[] args) {
		Mobile2020 phones  = new Mobilefor2020();
		

	}

}
