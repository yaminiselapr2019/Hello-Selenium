package week3.day1;

public class MySamsung {
	public static void main(String[] args) {
		Samsung phone = new Samsung();
		phone.dialCaller(2); // this from from Super class
		phone.samsungPay(); // this is from Sub Class (Samsung)
		
	}
}
