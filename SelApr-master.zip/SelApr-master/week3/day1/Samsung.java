package week3.day1;

public class Samsung extends Mobile{

	public void samsungPay() {
		System.out.println("This is a spl feature of Samsung by Tap!");
	}
	
	public void samsungPay(String userName) {
		System.out.println("This is a spl feature of Samsung by userName!");
	}
	
	public void dialCaller(int number) {
		System.out.println("Call using voice");
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}