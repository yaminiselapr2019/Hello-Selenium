package week3.day1;

// This is the base class
public class Vehicle {

	public void applyBrake() {
		System.out.println("Brake applied from Vehicle");
	}

	public void soundHorn() {
		System.out.println("Horn pressed from Vehicle");
	}

}
